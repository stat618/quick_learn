
print("hello world")